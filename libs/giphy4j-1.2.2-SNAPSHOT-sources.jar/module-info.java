module com.trievosoftware.giphy4j {
    requires com.google.gson;
    requires org.apache.commons.io;

    exports com.trievosoftware.giphy4j;
    exports com.trievosoftware.giphy4j.dao;
    exports com.trievosoftware.giphy4j.entity.giphy;
    exports com.trievosoftware.giphy4j.entity.search;
    exports com.trievosoftware.giphy4j.exception;
    exports com.trievosoftware.giphy4j.http;

    // Open entity packages to gson for reflection
    opens com.trievosoftware.giphy4j.entity.common to com.google.gson;
    opens com.trievosoftware.giphy4j.entity.giphy to com.google.gson;
    opens com.trievosoftware.giphy4j.entity.search to com.google.gson;
}
